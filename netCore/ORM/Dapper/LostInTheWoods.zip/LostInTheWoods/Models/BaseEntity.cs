namespace LostInTheWoods.Models
{
    public abstract class BaseEntity {}
}