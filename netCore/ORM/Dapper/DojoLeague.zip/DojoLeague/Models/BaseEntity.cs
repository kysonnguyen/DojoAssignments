namespace DojoLeague.Models
{
    public abstract class BaseEntity {}
}