namespace thewall.Models
{
     public abstract class BaseEntity {}
}